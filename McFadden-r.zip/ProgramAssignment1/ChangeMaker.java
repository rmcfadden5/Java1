import java.util.Scanner;

public class ChangeMaker
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        
        System.out.print("Enter your item's price (in cents): ");
        int itemPrice = in.nextInt();
        
        int originalAmount = (100 - itemPrice);
        int amount = originalAmount;
        int quarters = (amount / 25);
         amount = (amount % 25);
        int dimes = (amount / 10);
         amount = (amount % 10);
        int nickels = (amount / 5);
         amount = (amount % 5);
        int pennies = (amount / 1);
        
        System.out.println("Quarters = " + quarters);
        System.out.println("Dimes = " + dimes);
        System.out.println("Nickels = " + nickels);
        System.out.println("Pennies = " + pennies);
    }
}
